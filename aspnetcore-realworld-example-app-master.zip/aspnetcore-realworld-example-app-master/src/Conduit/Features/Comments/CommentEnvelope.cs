using Conduit.Domain;

namespace Conduit.Features.Comments
{
    public record CommentEnvelope(Comment Comment);
}
