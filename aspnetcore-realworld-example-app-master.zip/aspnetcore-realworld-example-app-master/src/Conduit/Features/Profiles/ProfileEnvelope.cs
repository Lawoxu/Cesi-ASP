namespace Conduit.Features.Profiles
{
    public record ProfileEnvelope(Profile Profile);
}
